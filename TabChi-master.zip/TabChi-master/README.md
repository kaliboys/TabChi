# [TabChi](http://yon.ir/4cR3)
* **Install Bot**
`````sh
yon.ir/4cR3
`````
